<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Illuminate\Support\Facades\Storage;

class ImageController extends Controller
{
    public function showUploadForm()
    {
        return view('images.upload');
    }

    public function upload(Request $request)
    {
        $request->validate([
            'image' => 'required|image',
        ]);
        $file = $request->file('image');
        $path = $file->store('images', 'public');
        $features = $this->extractAdvancedFeatures($file->getRealPath());
        $image = Image::create([
            'path' => $path,
            'vector' => json_encode($features),
        ]);
        return redirect()->back()->with('success', 'Image uploaded successfully!');
    }

    public function showSearchForm()
    {
        return view('images.search');
    }
    
    public function clearOldImages()
    {
        // Clear all images with old format
        Image::truncate();
        return redirect()->back()->with('success', 'Old images cleared. Please re-upload images with new format.');
    }

    public function search(Request $request)
    {
        $request->validate([
            'image' => 'required|image',
        ]);
        $file = $request->file('image');
        $queryFeatures = $this->extractAdvancedFeatures($file->getRealPath());
        $images = Image::all();
        $results = [];
        
        foreach ($images as $img) {
            if ($img->vector) {
                $storedFeatures = json_decode($img->vector, true);
                
                // Check if stored features are in new format
                if (is_array($storedFeatures) && isset($storedFeatures['phash'])) {
                    $similarity = $this->calculateAdvancedSimilarity($queryFeatures, $storedFeatures);
                    
                    // Only include results with high similarity (like Google Images)
                    if ($similarity > 0.6) {
                        $results[] = [
                            'image' => $img,
                            'similarity' => $similarity,
                        ];
                    }
                } else {
                    // Skip old format images or show message
                    continue;
                }
            }
        }
        
        usort($results, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });
        
        return view('images.results', ['results' => $results]);
    }

    private function extractAdvancedFeatures($path)
    {
        $manager = new ImageManager(new Driver());
        $img = $manager->read($path);
        
        // Resize to standard size for comparison
        $img = $img->resize(128, 128);
        
        $features = [];
        
        // 1. Perceptual Hash (pHash) - very accurate for similar images
        $features['phash'] = $this->calculatePerceptualHash($img);
        
        // 2. Color moments (mean, variance, skewness)
        $features['color_moments'] = $this->calculateColorMoments($img);
        
        // 3. Dominant colors
        $features['dominant_colors'] = $this->extractDominantColors($img);
        
        // 4. Edge density and distribution
        $features['edge_features'] = $this->calculateEdgeFeatures($img);
        
        // 5. Simple texture features (avoiding boundary issues)
        $features['texture_simple'] = $this->calculateSimpleTextureFeatures($img);
        
        return $features;
    }
    
    private function calculatePerceptualHash($img)
    {
        // Convert to grayscale and resize to 32x32
        $gray = $img->greyscale()->resize(32, 32);
        
        // Calculate DCT (Discrete Cosine Transform) approximation
        $pixels = [];
        for ($y = 0; $y < 32; $y++) {
            for ($x = 0; $x < 32; $x++) {
                $pixels[] = $gray->pickColor($x, $y)->toArray()[0];
            }
        }
        
        // Calculate mean
        $mean = array_sum($pixels) / count($pixels);
        
        // Create hash based on whether pixel is above or below mean
        $hash = '';
        foreach ($pixels as $pixel) {
            $hash .= ($pixel > $mean) ? '1' : '0';
        }
        
        return $hash;
    }
    
    private function calculateColorMoments($img)
    {
        $red = []; $green = []; $blue = [];
        
        // Get actual image dimensions
        $width = $img->width();
        $height = $img->height();
        
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $color = $img->pickColor($x, $y)->toArray();
                $red[] = $color[0];
                $green[] = $color[1];
                $blue[] = $color[2];
            }
        }
        
        $moments = [];
        foreach ([$red, $green, $blue] as $channel) {
            $mean = array_sum($channel) / count($channel);
            $variance = 0;
            $skewness = 0;
            
            foreach ($channel as $pixel) {
                $diff = $pixel - $mean;
                $variance += $diff * $diff;
                $skewness += $diff * $diff * $diff;
            }
            
            $variance /= count($channel);
            $skewness /= count($channel);
            
            $moments[] = $mean / 255;
            $moments[] = sqrt($variance) / 255;
            $moments[] = pow($skewness, 1/3) / 255;
        }
        
        return $moments;
    }
    
    private function extractDominantColors($img)
    {
        $colors = [];
        $colorCounts = [];
        
        // Get actual image dimensions
        $width = $img->width();
        $height = $img->height();
        
        // Sample pixels and count colors
        for ($y = 0; $y < $height; $y += 4) {
            for ($x = 0; $x < $width; $x += 4) {
                $color = $img->pickColor($x, $y)->toArray();
                $key = floor($color[0]/32) . '_' . floor($color[1]/32) . '_' . floor($color[2]/32);
                $colorCounts[$key] = ($colorCounts[$key] ?? 0) + 1;
            }
        }
        
        // Get top 8 dominant colors
        arsort($colorCounts);
        $dominant = array_slice($colorCounts, 0, 8, true);
        
        foreach ($dominant as $colorKey => $count) {
            $parts = explode('_', $colorKey);
            $colors[] = [
                'r' => $parts[0] * 32 / 255,
                'g' => $parts[1] * 32 / 255,
                'b' => $parts[2] * 32 / 255,
                'weight' => $count / array_sum($colorCounts)
            ];
        }
        
        return $colors;
    }
    
    private function calculateEdgeFeatures($img)
    {
        $gray = $img->greyscale();
        $edges = [];
        
        // Get actual image dimensions
        $width = $img->width();
        $height = $img->height();
        
        // Sobel edge detection - avoid boundaries
        for ($y = 1; $y < $height - 1; $y++) {
            for ($x = 1; $x < $width - 1; $x++) {
                $center = $gray->pickColor($x, $y)->toArray()[0];
                $right = $gray->pickColor($x + 1, $y)->toArray()[0];
                $left = $gray->pickColor($x - 1, $y)->toArray()[0];
                $top = $gray->pickColor($x, $y - 1)->toArray()[0];
                $bottom = $gray->pickColor($x, $y + 1)->toArray()[0];
                
                $gx = $right - $left;
                $gy = $bottom - $top;
                $magnitude = sqrt($gx * $gx + $gy * $gy);
                
                $edges[] = $magnitude > 50 ? 1 : 0;
            }
        }
        
        $edgeDensity = array_sum($edges) / count($edges);
        
        // Edge direction histogram - avoid boundaries
        $directions = [0, 0, 0, 0]; // 0°, 45°, 90°, 135°
        for ($y = 1; $y < $height - 1; $y++) {
            for ($x = 1; $x < $width - 1; $x++) {
                $center = $gray->pickColor($x, $y)->toArray()[0];
                $right = $gray->pickColor($x + 1, $y)->toArray()[0];
                $bottom = $gray->pickColor($x, $y + 1)->toArray()[0];
                
                $gx = $right - $center;
                $gy = $bottom - $center;
                
                $angle = atan2($gy, $gx) * 180 / M_PI;
                if ($angle < 0) $angle += 180;
                
                $bin = floor($angle / 45);
                if ($bin >= 4) $bin = 3;
                $directions[$bin]++;
            }
        }
        
        $total = array_sum($directions);
        $directions = array_map(function($val) use ($total) {
            return $total > 0 ? $val / $total : 0;
        }, $directions);
        
        return array_merge([$edgeDensity], $directions);
    }
    
    private function calculateSimpleTextureFeatures($img)
    {
        $gray = $img->greyscale();
        $pixels = [];
        
        // Get actual image dimensions
        $width = $img->width();
        $height = $img->height();
        
        // Get pixel values for texture analysis
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $pixels[] = $gray->pickColor($x, $y)->toArray()[0];
            }
        }
        
        // Calculate texture features
        $mean = array_sum($pixels) / count($pixels);
        $variance = 0;
        
        foreach ($pixels as $pixel) {
            $variance += pow($pixel - $mean, 2);
        }
        $variance /= count($pixels);
        
        return [$mean / 255, sqrt($variance) / 255]; // Normalize to 0-1
    }
    
    private function calculateAdvancedSimilarity($features1, $features2)
    {
        $totalSimilarity = 0;
        $weights = [
            'phash' => 0.4,           // Perceptual hash - most important
            'color_moments' => 0.25,  // Color moments
            'dominant_colors' => 0.2, // Dominant colors
            'edge_features' => 0.1,   // Edge features
            'texture_simple' => 0.05  // Texture features
        ];
        
        // 1. Perceptual Hash similarity (Hamming distance)
        $phashSim = $this->calculateHashSimilarity($features1['phash'], $features2['phash']);
        $totalSimilarity += $weights['phash'] * $phashSim;
        
        // 2. Color moments similarity
        $colorSim = $this->cosineSimilarity($features1['color_moments'], $features2['color_moments']);
        $totalSimilarity += $weights['color_moments'] * $colorSim;
        
        // 3. Dominant colors similarity
        $dominantSim = $this->calculateDominantColorSimilarity($features1['dominant_colors'], $features2['dominant_colors']);
        $totalSimilarity += $weights['dominant_colors'] * $dominantSim;
        
        // 4. Edge features similarity
        $edgeSim = $this->cosineSimilarity($features1['edge_features'], $features2['edge_features']);
        $totalSimilarity += $weights['edge_features'] * $edgeSim;
        
        // 5. Texture similarity
        $textureSim = $this->cosineSimilarity($features1['texture_simple'], $features2['texture_simple']);
        $totalSimilarity += $weights['texture_simple'] * $textureSim;
        
        return $totalSimilarity;
    }
    
    private function calculateHashSimilarity($hash1, $hash2)
    {
        $hammingDistance = 0;
        for ($i = 0; $i < strlen($hash1); $i++) {
            if ($hash1[$i] !== $hash2[$i]) {
                $hammingDistance++;
            }
        }
        
        // Convert Hamming distance to similarity (0-1)
        $maxDistance = strlen($hash1);
        return 1 - ($hammingDistance / $maxDistance);
    }
    
    private function calculateDominantColorSimilarity($colors1, $colors2)
    {
        $similarity = 0;
        $totalWeight = 0;
        
        foreach ($colors1 as $color1) {
            $bestMatch = 0;
            foreach ($colors2 as $color2) {
                $colorSim = $this->calculateColorDistance($color1, $color2);
                $bestMatch = max($bestMatch, $colorSim);
            }
            $similarity += $color1['weight'] * $bestMatch;
            $totalWeight += $color1['weight'];
        }
        
        return $totalWeight > 0 ? $similarity / $totalWeight : 0;
    }
    
    private function calculateColorDistance($color1, $color2)
    {
        $dr = $color1['r'] - $color2['r'];
        $dg = $color1['g'] - $color2['g'];
        $db = $color1['b'] - $color2['b'];
        
        $distance = sqrt($dr*$dr + $dg*$dg + $db*$db);
        return max(0, 1 - $distance);
    }
    
    private function cosineSimilarity($vec1, $vec2)
    {
        if (count($vec1) !== count($vec2)) {
            return 0;
        }
        
        $dot = 0;
        $normA = 0;
        $normB = 0;
        
        for ($i = 0; $i < count($vec1); $i++) {
            $dot += $vec1[$i] * $vec2[$i];
            $normA += $vec1[$i] * $vec1[$i];
            $normB += $vec2[$i] * $vec2[$i];
        }
        
        $normA = sqrt($normA);
        $normB = sqrt($normB);
        
        if ($normA == 0 || $normB == 0) {
            return 0;
        }
        
        return $dot / ($normA * $normB);
    }
}

