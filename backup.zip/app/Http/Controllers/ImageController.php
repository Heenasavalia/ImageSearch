<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use Illuminate\Support\Facades\Storage;

class ImageController extends Controller
{
    public function showUploadForm()
    {
        return view('images.upload');
    }

    public function upload(Request $request)
    {
        $request->validate([
            'image' => 'required|image',
        ]);
        $file = $request->file('image');
        $path = $file->store('images', 'public');
        $vector = $this->extractFeatures($file->getRealPath());
        $image = Image::create([
            'path' => $path,
            'vector' => json_encode($vector),
        ]);
        return redirect()->back()->with('success', 'Image uploaded!');
    }

    public function showSearchForm()
    {
        return view('images.search');
    }

    public function search(Request $request)
    {
        $request->validate([
            'image' => 'required|image',
        ]);
        $file = $request->file('image');
        $queryVector = $this->extractFeatures($file->getRealPath());
        $images = Image::all();
        $results = [];
        foreach ($images as $img) {
            if ($img->vector) {
                $vector = json_decode($img->vector, true);
                $similarity = $this->cosineSimilarity($queryVector, $vector);
                $results[] = [
                    'image' => $img,
                    'similarity' => $similarity,
                ];
            }
        }
        usort($results, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });
        return view('images.results', ['results' => $results]);
    }

    private function extractFeatures($path)
    {
        $manager = new ImageManager(new Driver());
        $img = $manager->read($path)->resize(32, 32)->greyscale();
        $pixels = [];
        for ($y = 0; $y < 32; $y++) {
            for ($x = 0; $x < 32; $x++) {
                $color = $img->pickColor($x, $y);
                $pixels[] = $color->toArray()[0];
            }
        }
        return $pixels;
    }

    private function cosineSimilarity($vec1, $vec2)
    {
        $dot = 0;
        $normA = 0;
        $normB = 0;
        for ($i = 0; $i < count($vec1); $i++) {
            $dot += $vec1[$i] * $vec2[$i];
            $normA += $vec1[$i] ** 2;
            $normB += $vec2[$i] ** 2;
        }
        return $dot / (sqrt($normA) * sqrt($normB) + 1e-10);
    }
}
